<style type="text/css">

/*.bg{

  background:url(../images/bg/home_bg.png) no-repeat;
}
*/
/*.ssgmenu  > li > a {

  font-size: 25px; 
  padding: 15px;
  color: #6f0305;

} 
.ssgmenu > li > a:hover,
.ssgmenu > li > a:focus{
  background: #ff9933;
  color: #6f0305;
} 
 
.motto p {
  font-size: 32px;
  font-weight: bold;
  margin-top: 5%;

}
.motto{
  text-shadow: 1px 1px 4px rgba(0, 0, 0, 1);
  color: #6f0305;
  font-size:16px;
    
}
.timeh1{
   text-shadow: 1px 1px 4px rgba(0, 0, 0, 1);
  color: #6f0305;
 */
/*}*/
 
#wrap { 
  min-height: 265px;
  width: 600px;

}
#wrap img {  
  width: 100%;
  height: 100%;
  text-align: center;  
}  


</style>  
  <section id="feature" class="transparent-bg"   >
        <div class="container bg"> 
            <div class="row">
                <div class="features"  >
                 
                   
<div class="container" id="wrap"> 

				<div id="wrap">
					<img src="img/bg/fbc_logo.png" />
				</div>
                           
                </div><!--/.services-->
            </div><!--/.row-->  
        </div><!--/.container-->
    </section><!--/#feature--> 


  

