 <table class="table table-striped  table-responsive"> 
    <tr> 
    </tr> 
    <tr>
      <td ><label>Vacation :</label></td> 
      <td colspan="2">
        <label><?php echo $lcredits->VACATION; ?></label>
      </td> 
      <td ><label>Sick :</label></td>
      <td colspan="2"> 
      <div class="input-group " > 
          <label><?php echo  $lcredits->SICK; ?> </label>   
       </div>             
      </td> 
    </tr> 
    <tr>
    <td ><label>Maternity :</label></td>
      <td colspan="2"> 
      <div class="input-group " > 
          <label><?php echo  $lcredits->MATERNITY; ?> </label>   
       </div>             
      </td> 
    <!--    <td  ><label>Emergency</label></td>
      <td colspan="2">
        <label><?php echo $lcredits->EMERGENCY; ?></label> 
       </td> -->
   <!--  <td><label>SSS :</label></td>
      <td colspan="2" >
        <label><?php echo $lcredits->SSS; ?></label> 
            </td> -->
    
 <!--    </tr>  
    <tr> -->
    <!--  <td  ><label>Emergency</label></td>
      <td colspan="2">
        <label><?php echo $lcredits->EMERGENCY; ?></label> 
            </td> -->
    <td><label>Service Credits :</label></td>
      <td colspan="2" >
        <label><?php echo $lcredits->OTHERS; ?></label> 
            </td>
   
    </tr>
    <tr> 
      <td colspan="6">   
      </td>
    </tr>
  </table>   