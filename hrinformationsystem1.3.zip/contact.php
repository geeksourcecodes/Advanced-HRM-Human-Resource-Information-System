      
<style type="text/css">

 
#background {
    margin-top: 80px; 
    width: 100%; 
    height: 90%; 
    position: fixed; 
    left: 0px; 
    top: 0px; 
    z-index: -1; /* Ensure div tag stays behind content; -999 might work, too. */
}

.stretch {
    width:100%;
    height:100%;
}
.motto{
  text-shadow: 1px 1px 4px rgba(0, 0, 0, 1);
  color: #6f0305;
  font-size:30px;
    
}

 
</style>  
  <section id="feature" class="transparent-bg"  >
        <div class="container "> 
            <div class="row">
                <div class="features">

                <div class="col-lg-12">
                    <div class="panel panel-default">
                     <div class="panel-heading">
                            <h1 class="motto"> Contact Us 
                           </h1>
                        </div>
                         
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                         <!-- Map Column -->
            
            <!-- Contact Details Column -->
            <div class="col-md-12">
                <h3>Contact Details</h3>
                <p>
                   Rizal St., Kabankalan City 6111  Negros Occidental Philippines 
                </p>
                <p><i class="fa fa-phone"></i> 
                    <abbr title="Phone">Phone</abbr>: +63 34 4712156 </p>
                <p><i class="fa fa-fax"></i> 
                    <abbr title="Fax">Fax</abbr>: +63 34 4712156 </p>
                <p><i class="fa fa-envelope-o"></i> 
                    <abbr title="Email">Email</abbr>: info@fbc.edu.ph 
                </p>
                <p><i class="fa fa-clock-o"></i> 
                    <abbr title="Hours">H</abbr>: Monday - Friday: 9:00 AM to 5:00 PM</p>
               
            </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 --> 
            
                 <div  id="background">
                   <img src="admin/img/bg/fbc.jpg" class="stretch">
                   
                 </div> 
                </div><!--/.services-->
            </div><!--/.row-->  
        </div><!--/.container-->
    </section><!--/#feature--> 
 



