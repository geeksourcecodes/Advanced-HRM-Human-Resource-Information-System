      
<style type="text/css">

 
#background {
    margin-top: 80px; 
    width: 100%; 
    height: 90%; 
    position: fixed; 
    left: 0px; 
    top: 0px; 
    z-index: -1; /* Ensure div tag stays behind content; -999 might work, too. */
}

.stretch {
    width:100%;
    height:100%;
}
.motto{
  text-shadow: 1px 1px 4px rgba(0, 0, 0, 1);
  color: #6f0305;
  font-size:30px;
    
}

 
</style>  
  <section id="feature" class="transparent-bg"  >
        <div class="container "> 
            <div class="row">
                <div class="features">
                 <div class="col-lg-12">
                    <div class="panel panel-default">
                     <div class="panel-heading">
                            <h1 class="motto"> History 
                           </h1>
                        </div>
                         
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                          <p>

                            Fellowship Baptist Academy is a fundamental Christian secondary school on Western Visayas founded in 1954 by a group of Baptist lay-leaders, ministers and missionaries of the Visayan Fellowship of Fundamental Baptist Churches. It is sectarian, non-stock, non-profit educational institution. Aside from student fees, it exists mainly upon benevolent donations from Fundamental Baptist churches organization, individual Christians and later from the alumni and its organization.
<br/>
<br/>
                            It opened in 1954 with an enrollment of 212 students. It faithfully carried out its mission. In 1957, Fellowship Baptist Academy was given government recognition. Today, graduates of the school have spread far and wide not only in the Philippines but in other countries. Some leaders are occupying sensitive positions in various fields of human endeavors. Some accepted the highest calling as ministers, evangelists and missionaries here and abroad.
<br/>
<br/>
                            Aware of the need for educational expansion of our Christian youths, decisive steps were taken by the administration to convert the school into a full-fledge college. The long cherished dream was at last realized. For with the Lord nothing is impossible.
<br/>
<br/>
                            In June 1982, the school operated a post-secondary course in Midwifery. The following year, it opened two degree courses which are Bachelor of Science in Business administration and Bachelor of Arts. Upon conferring the government recognition to these two courses, DECS acted favorably in school year 1989-1990 on the change of the status of the school from “Academy” to “College”. Additional courses were later offered such as BSED, BEED, BSA, BSN, AAS, HA, PA, Caregiver, Two-Year and One-Year Computer courses. If the Lord tarries, FBC will offer more courses.
<br/>
<br/>
                            The school stands true to its commitment: To win Souls for Christ till He comes .
                               
                         </p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            
                 <div  id="background">
                   <img src="admin/img/bg/fbc.jpg" class="stretch">
                   
                 </div> 
                </div><!--/.services-->
            </div><!--/.row-->  
        </div><!--/.container-->
    </section><!--/#feature--> 
 